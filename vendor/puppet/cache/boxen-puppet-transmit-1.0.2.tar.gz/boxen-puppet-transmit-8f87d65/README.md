# Puppet module for Transmit

[![Build Status](https://travis-ci.org/boxen/puppet-transmit.png)](https://travis-ci.org/boxen/puppet-transmit)

Installs Transmit, a great FTP / SFTP / etc client from Panic.

http://panic.com/transmit/

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

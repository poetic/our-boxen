# Puppet module for Transmit

Installs Transmit, a great FTP / SFTP / etc client from Panic.

http://panic.com/transmit/

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

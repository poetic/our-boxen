# Synergy Puppet Module for Boxen

## Usage

```puppet
include synergy
```

## Required Puppet Modules

* `boxen`

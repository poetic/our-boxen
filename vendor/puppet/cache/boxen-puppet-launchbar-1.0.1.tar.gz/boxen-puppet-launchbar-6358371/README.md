# Launchbar Puppet Module for Boxen

A boxen module for launchbar :)

[![Build Status](https://travis-ci.org/hco/puppet-launchbar.png?branch=master)](https://travis-ci.org/hco/puppet-launchbar)

## Usage

```puppet
include phpstorm
```

## Required Puppet Modules

* `boxen`

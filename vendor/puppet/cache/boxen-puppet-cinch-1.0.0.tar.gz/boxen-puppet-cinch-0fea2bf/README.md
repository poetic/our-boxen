# Cinch Puppet Module for Boxen

Installs [Cinch](http://www.irradiatedsoftware.com/cinch).

## Usage

```puppet
include cinch
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

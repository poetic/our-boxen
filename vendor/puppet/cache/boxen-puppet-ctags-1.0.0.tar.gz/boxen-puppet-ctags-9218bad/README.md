# Ctags Puppet Module for Boxen
More info at [http://ctags.sourceforge.net/](http://ctags.sourceforge.net/). 

## Usage

```puppet
include ctags
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`


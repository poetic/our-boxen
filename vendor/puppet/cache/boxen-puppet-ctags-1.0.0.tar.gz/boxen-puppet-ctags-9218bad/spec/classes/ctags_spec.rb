require 'spec_helper'

describe 'ctags' do
  it { should contain_package('ctags') }
end

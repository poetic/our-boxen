# Puppet module for Pow

Installs Pow, a simple app server from 37 Signals.

http://pow.cx

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.

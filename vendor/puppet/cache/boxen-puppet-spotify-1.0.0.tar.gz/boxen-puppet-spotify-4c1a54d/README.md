# Spotify Puppet Module for Boxen

## Usage

```puppet
include spotify
```

## Required Puppet Modules

* boxen

## Developing

Write code.

Run `script/cibuild`.

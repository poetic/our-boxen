# QT Puppet Module for Boxen

## Usage

```puppet
include qt
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
* `xquartz`

# SOLR Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-solr.png?branch=master)](https://travis-ci.org/boxen/puppet-solr)

## Usage

```puppet
include solr
```

## Required Puppet Modules

* boxen
* homebrew
* java
* stdlib

# SOLR Puppet Module for Boxen

[![Build Status](https://travis-ci.org/boxen/puppet-solr.png?branch=master)](https://travis-ci.org/boxen/puppet-solr)

## Usage

```puppet
include solr
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `repository`
* `java`
* `stdlib`

## Development

Then write some code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
